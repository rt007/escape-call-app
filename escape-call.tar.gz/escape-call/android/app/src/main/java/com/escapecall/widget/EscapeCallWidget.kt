package com.escapecall.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import com.escapecall.R
import com.escapecall.network.TriggerCallService

/**
 * Homescreen widget — a single tap triggers the escape call.
 *
 * Flow:  Widget tap → PendingIntent → TriggerCallService → API call → Twilio → incoming call
 */
class EscapeCallWidget : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (widgetId in appWidgetIds) {
            updateWidget(context, appWidgetManager, widgetId)
        }
    }

    companion object {
        private const val ACTION_TRIGGER = "com.escapecall.ACTION_TRIGGER_CALL"

        fun updateWidget(
            context: Context,
            appWidgetManager: AppWidgetManager,
            widgetId: Int
        ) {
            val intent = Intent(context, TriggerCallService::class.java)
            val pendingIntent = PendingIntent.getForegroundService(
                context,
                0,
                intent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )

            val views = RemoteViews(context.packageName, R.layout.widget_escape_call).apply {
                setOnClickPendingIntent(R.id.widget_button, pendingIntent)
            }

            appWidgetManager.updateAppWidget(widgetId, views)
        }
    }
}
